#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>

#define HACKATON

uint32_t GETCPUTIME()
{
    // Works up to 100 Million cycles
    uint32_t count;
    do {
        asm volatile ("csrr %0, mcycle\t" :  "=r"(count):);
    } while (count > (4194967295));

    return count;
}

// ----------------------------------------------------------------------------
// Optimize!
void matmul(int *A, int *B, int *C, int rows_a, int cols_a, int cols_b) {
    // Initialize the result matrix C to zero
    for (int i = 0; i < rows_a * cols_b; i++) {
        C[i] = 0;
    }
    // Perform matrix multiplication
    for (int i = 0; i < rows_a; i++) {
        for (int j = 0; j < cols_b; j++) {
            for (int k = 0; k < cols_a; k++) {
                C[i * cols_b + j] += A[i * cols_a + k] * B[k * cols_b + j];
            }
        }
    }
}
void vecadd(int *A, int *B, int *C, int cols_a) {
    for (int i = 0; i < cols_a; i++) {
        C[i] = A[i] + B[i];
    }
}
void vecrelu(int *A, int *B, int cols_a) {
    for (int i = 0; i < cols_a; i++) {
        B[i] = A[i] > 0 ? A[i] : 0;
    }
}
void vecstep(int *A, int *B, int cols_a) {
    for (int i = 0; i < cols_a; i++) {
        B[i] = A[i] > 0 ? 1 : 0;
    }
}
// ----------------------------------------------------------------------------

void forward_pass(int * inputs, int * outputs) {

    int outmat_0[8], outmat_1[8], outmat_2[4], outmat_3[4], layer_1[8];

    int32_t weights_0[8*4] ={ 87,    -2,     0,    -6,   -10,   108,    87,    37,\
                             -95,   -31,   127,   116,    -2,   -53,   -87,     6,\
                              82,    39,   -96,   -16,  -100,   -85,    29,  -104,\
                              41,   -99,   -67,    51,   -92,   -31,   -66,   105};
    int32_t bias_0[8]      ={-29,    60,    36,   -35,   104,    62,    37,    -7};

    int32_t weights_1[4*8] ={-44,    33,   -31,   -28,\
                             -65,   -36,    58,    42,\
                             -10,   127,    19,    33,\
                              29,   -44,   -23,   -24,\
                             -69,   -34,   -75,    30,\
                              85,   -18,   -14,    18,\
                              94,   -16,    23,    25,\
                             -44,   -15,    56,   -33};
    int32_t bias_1[8]      ={-23,   -10,   -14,   -20};


    // Optimize the following neural network code!
    // ---------------------------------------------------------------------------------------------
    // Layer 0
    matmul(inputs,weights_0,outmat_0, 1, 4, 8); // Matrix multiplication. Layer input with weights.
    vecadd( outmat_0,bias_0,outmat_1,8);         // Vector addition. Add bias.
    vecrelu(outmat_1,layer_1,8);                // Neuron vector activation. ReLU.

    // Layer 1SA
    matmul(layer_1,weights_1,outmat_2, 1, 8, 4); // Matrix multiplication. Layer input with weights.
    vecadd(outmat_2,bias_1,outmat_3,4);          // Vector addition. Add bias.
    vecstep(outmat_3,outputs,4);                 // Neuron vector activation. Step.
    // ---------------------------------------------------------------------------------------------

}

int main() {

    int input_bin[4];
    int output_bin[4];
    int output_dec;
    uint32_t exectime = 0, a,b,t;
    int validate[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0};
    int err = 0;
    printf("-----------------------------------------------------\n");
    printf("MLP Counter Execution and Validation Routine Started!\n");
    printf("-----------------------------------------------------\n");


    for (int i = 0; i < 16; i++) {
        input_bin[0] = (i>>3)&0x1;
        input_bin[1] = (i>>2)&0x1;
        input_bin[2] = (i>>1)&0x1;
        input_bin[3] = (i>>0)&0x1;

        a = GETCPUTIME();
        forward_pass(input_bin, output_bin);
        b = GETCPUTIME();
        t = b-a;
        if (t<0) {
            t += 0x7fffffff;
        }
        exectime += t;

        output_dec  = (output_bin[0]<<3);
        output_dec |= (output_bin[1]<<2);
        output_dec |= (output_bin[2]<<1);
        output_dec |= (output_bin[3]<<0);

        err += abs(validate[i]-output_dec);
        printf("Counter Neural Network Test --> Input:%d Output:%d\n",i,output_dec);
        //printf("[%d %d %d %d] --> [%d %d %d %d]\n",input_bin[0],input_bin[1],input_bin[2],input_bin[3],output_bin[0],output_bin[1],output_bin[2],output_bin[3]);
    }

    if (!err) {
        printf("--> Validation PASSED! Cycles:%d\n",exectime);
    } else {
        printf("--> Validation FAILED! Cycles:%d\n",exectime);
    }
    printf("-----------------------------------------------------\n");

    return 0;
}
